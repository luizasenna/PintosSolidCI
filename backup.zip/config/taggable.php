<?php

return [
	'delimiters' => ',',
	'normalizer' => 'mb_strtolower',
];
