<?php
/**
* Language file for blog category table headings
*
*/

return array(

    'id'         => 'Id',
    'name'       => 'Наименование',
    'blogs'      => 'No. Блогов',
    'created_at' => 'Создано',
    'actions'	 => 'Действия',

);
