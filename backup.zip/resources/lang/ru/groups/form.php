<?php
/**
* Language file for group management form text
*
*/
return array(

    'name'			=> 'Наименование',
    'slug'          => 'Slug',
    'general' 		=> 'Основные',
    'permissions'	=> 'Права доступа',

);
