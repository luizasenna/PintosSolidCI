<?php

/**
* Language file for user delete modal
*
*/
return array(

    'body'			=> 'Are you sure to delete this user? This operation is irreversible.',
    'cancel'		=> 'Cancel',
    'confirm'		=> 'Delete',
    'title'         => 'Delete User',

);
