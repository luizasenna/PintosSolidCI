<?php
/**
* Language file for group management form text
*
*/
return array(

    'name'			=> 'Blog Category Name',
    'general' 		=> 'General',
);
