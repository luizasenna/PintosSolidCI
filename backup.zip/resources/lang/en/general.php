<?php
/**
* Language file for general strings
*
*/
return array(

    'no'  			=> 'No',
    'noresults'  	=> 'No Results',
    'yes' 			=> 'Yes',

);
