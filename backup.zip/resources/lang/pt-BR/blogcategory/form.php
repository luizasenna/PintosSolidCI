<?php
/**
* Language file for group management form text
*
*/
return array(

    'name'			=> 'Nome da Categoria do Blogue',
    'general' 		=> 'Geral',
);
