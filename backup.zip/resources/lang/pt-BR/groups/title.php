<?php
/**
* Language file for group section titles
*
*/

return array(

    'create'			=> 'Criar Novo Grupo',
    'edit' 				=> 'Editar Grupo',
    'management'	=> 'Gerenciar Grupos',

);
