<?php
/**
* Language file for group management form text
*
*/
return array(

    'name'			=> 'Blog categorie naam',
    'general' 		=> 'Algemeen',
);
