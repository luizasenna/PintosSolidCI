<?php
/**
* Language file for submit buttons across the site
*
*/
return array(

    'edit'    			=> 'Izmjena',
    'delete'  			=> 'Brisanje',
    'restore' 			=> 'Povrat',
    'publish' 			=> 'Objava',
    'save'	  			=> 'Sa?uvaj',
    'submit'	  		=> 'Po�alji',
    'cancel'  			=> 'Odustani',
    'create'  			=> 'Kreiraj',
    'back'    			=> 'Nazad',
    'signin'  			=> 'Prijavi se',
    'forgotpassword' 	=> 'Zaboravio sam lozinku',
    'rememberme'		=> 'Zapamti me',
    'signup'			=> 'Registracija',
    'update'			=> 'Izmjena',

);
