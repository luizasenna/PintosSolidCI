<?php
/**
* Language file for general strings
*
*/
return array(

    'no'  			=> 'Ne',
    'noresults'  	=> 'Nema rezultata',
    'yes' 			=> 'Da',

);
