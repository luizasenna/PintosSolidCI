<?php

/**
 * Language file for delete modal
 *
 */
return array(

    'title'         => "Supprimer l'élément",
    'body'			=> 'Êtes-vous sûr de vouloir supprimer cet élément ? Cette opération est irréverssible.',
    'cancel'		=> 'Annuler',
    'confirm'		=> 'Supprimer',

);
