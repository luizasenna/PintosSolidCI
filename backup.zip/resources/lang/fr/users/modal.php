<?php

/**
* Language file for user delete modal
*
*/
return array(

    'body'			=> 'Êtes-vous sûr de vouloir supprimer cet utilisateur ? Cette opération est irréverssible.',
    'cancel'		=> 'Annuler',
    'confirm'		=> 'Supprimer',
    'title'         => "Supprimer l'utilisateur",

);
