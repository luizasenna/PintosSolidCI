$(document).ready(function() {
    $('.textarea').summernote();
    $('.select2').select2({
        placeholder: placeholder
    });
});