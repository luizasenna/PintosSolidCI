$(function() {
    $('#alert_msg').delay(5000).fadeOut(200);
});
